import React from 'react';
import DashboardPage from "../Components/DashboardPage/DashboardPage";

function Dashboard(props) {
    return (
        <>
            <DashboardPage/>
        </>
    );
}

export default Dashboard;